<?php
return array (
  0 => 
  array (
    'App\\Bootstrap' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Bootstrap.php',
      1 => 1754528516,
    ),
    'App\\Core\\ApiPresenter' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Core\\ApiPresenter.php',
      1 => 1762813024,
    ),
    'App\\Core\\RouterFactory' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Core\\RouterFactory.php',
      1 => 1762740729,
    ),
    'App\\Model\\Modelautor' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Model\\Modelautor.php',
      1 => 1762735060,
    ),
    'App\\Model\\Modelcategoria' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Model\\Modelcategoria.php',
      1 => 1762479496,
    ),
    'App\\Model\\Modelposts' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Model\\Modelposts.php',
      1 => 1762740267,
    ),
    'App\\Model\\Modeltags' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Model\\Modeltags.php',
      1 => 1762738496,
    ),
    'App\\Presentation\\Accessory\\LatteExtension' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Presentation\\Accessory\\LatteExtension.php',
      1 => 1754528516,
    ),
    'App\\Presentation\\Autor\\AutorPresenter' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Presentation\\Autor\\AutorPresenter.php',
      1 => 1762735058,
    ),
    'App\\Presentation\\Categoria\\CategoriaPresenter' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Presentation\\Categoria\\CategoriaPresenter.php',
      1 => 1762737851,
    ),
    'App\\Presentation\\Error\\Error4xx\\Error4xxPresenter' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Presentation\\Error\\Error4xx\\Error4xxPresenter.php',
      1 => 1754528516,
    ),
    'App\\Presentation\\Error\\Error5xx\\Error5xxPresenter' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Presentation\\Error\\Error5xx\\Error5xxPresenter.php',
      1 => 1754528516,
    ),
    'App\\Presentation\\Home\\HomePresenter' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Presentation\\Home\\HomePresenter.php',
      1 => 1762304367,
    ),
    'App\\Presentation\\Posts\\PostsPresenter' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Presentation\\Posts\\PostsPresenter.php',
      1 => 1762741321,
    ),
    'App\\Presentation\\Tags\\TagsPresenter' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetoNette\\projetoNette\\app\\Presentation\\Tags\\TagsPresenter.php',
      1 => 1762813505,
    ),
  ),
  1 => 
  array (
    'null' => 3,
    'App\\Presentation\\Tag\\TagPresenter' => 2,
    'App\\Presentation\\Categorias\\CategoriasPresenter' => 3,
    'App\\Presentation\\Post\\PostPresenter' => 2,
  ),
  2 => 
  array (
  ),
);
